-- Drop database if exists
drop database if exists twitter;

-- Create new database
create database twitter;

use twitter;

-- Create table posts

CREATE TABLE `posts` (
  `id` int(11) NOT NULL COMMENT 'post id#' AUTO_INCREMENT,
  `userid` varchar(40) NOT NULL,
  `post` varchar(140) NOT NULL,
  `created` int(10) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- Create table users

CREATE TABLE `users` (
  `userid` varchar(40) NOT NULL,
  `created` int(10) NOT NULL,
  `password` varchar(40) NOT NULL,
    UNIQUE KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


-- Insert default user 

INSERT INTO `users` (`userid`,`created`, `password`) VALUES
('myproject', 1523174889, 'welcometotwitter');

-- Insert default post

INSERT INTO `posts` (`id`, `userid`, `post`, `created`) VALUES
('1', 'myproject', 'hello', 1523174889);